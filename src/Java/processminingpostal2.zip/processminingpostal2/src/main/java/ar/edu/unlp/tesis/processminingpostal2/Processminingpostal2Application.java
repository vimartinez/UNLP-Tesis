package ar.edu.unlp.tesis.processminingpostal2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Processminingpostal2Application {

	public static void main(String[] args) {
		SpringApplication.run(Processminingpostal2Application.class, args);
	}

}
