package ar.edu.unlp.tesis.processminingpostal2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Processminingpostal2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
